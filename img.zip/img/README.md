# The Images folder

In most HTML projects, a common project structure will include a folder called `img`, `images`, `assets` or otherwise to contain images for the project.
